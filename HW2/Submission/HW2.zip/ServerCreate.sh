#!/bin/bash
# Retriever test
./Server $1

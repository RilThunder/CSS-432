#!/bin/bash
# Retriever for case 2, accessing a real server




./Retriever $1 $2 80
cat content.txt
